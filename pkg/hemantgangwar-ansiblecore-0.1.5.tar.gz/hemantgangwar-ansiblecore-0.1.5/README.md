# ansiblecore

Welcome to ansiblecore. A module written to play along with Ansible, for more details on free content written by author on Ansible, please refer: (#https://learningtechnix.wordpress.com/category/automation/ansible/)

## Table of Contents

1. [Description](#description)
2. [Setup - The basics of getting started with ansiblecore](#setup)

## Description

For those who are looking for a clean ansible installation in their environment. For this a preferable setup is RHEL / CentOS 7 based machines.

## Setup

In this example code you will find numerous machines, where following are important:

- ldapmas.technix.com --> ANSIBLE MASTER
- master.lab.example.com --> ANSIBLE CLIENT

